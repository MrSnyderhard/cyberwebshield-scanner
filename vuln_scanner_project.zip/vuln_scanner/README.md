# Design and Development of an Automated Web Vulnerability Scanner Using Python

**Project Title:** Design and Development of an Automated Web Vulnerability Scanner Using Python  
**Type:** Academic / Cybersecurity Research Project  
**Language:** Python 3.10+  

---

## 📋 Project Overview

This project presents a fully automated web vulnerability scanner built in Python.
It crawls a target website and runs six security analysis modules to detect common
web vulnerabilities including SQL Injection, XSS, missing security headers, SSL issues,
open redirects, and sensitive file exposure.

---

## 🚀 Setup & Installation

```bash
# 1. Clone / extract the project
cd vuln_scanner

# 2. (Optional) Create virtual environment
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Run the scanner
python3 scanner.py http://testphp.vulnweb.com
```

---

## 🔬 Scanner Modules

| Module | Severity | Description |
|---|---|---|
| SQL Injection | CRITICAL | 10+ payloads, DB error detection |
| XSS Detection | HIGH | 8 reflected XSS payloads |
| Security Headers | MEDIUM | 7 headers checked |
| SSL/TLS Analysis | HIGH | Certificate validity & HTTPS check |
| Open Redirect | MEDIUM | Tests redirect parameters |
| Sensitive File Exposure | HIGH | 18 common paths probed |

---

## 🌐 Legally Scannable Test Targets

These sites are **intentionally vulnerable** and publicly available for security research:

| Site | URL | Key Vulnerabilities |
|---|---|---|
| Acunetix TestPHP | http://testphp.vulnweb.com | SQLi, XSS, Dir Traversal |
| WebScanTest | http://www.webscantest.com | SQLi, XSS, Headers |
| Zero WebApp Security | http://zero.webappsecurity.com | Broken Auth, IDOR |
| HackYourselfFirst | http://hackyourselffirst.troyhunt.com | SQLi, CSRF, IDOR |
| OWASP Juice Shop | https://juice-shop.herokuapp.com | OWASP Top 10 |
| DVWA (local) | http://localhost/dvwa | All vulnerability classes |

---

## 📁 Project Structure

```
vuln_scanner/
├── scanner.py          # Main scanner orchestrator
├── requirements.txt    # Python dependencies
├── README.md           # This file
├── reports/            # Auto-generated scan reports
│   ├── report_*.json
│   └── report_*.txt
└── templates/
    └── index.html      # Web UI frontend
```

---

## 📊 Sample Output

```
[*] Target: http://testphp.vulnweb.com
[*] Crawling site...
[+] Crawled 12 pages, found 3 forms

[*] Running SQL Injection scan...
[-] CRITICAL: SQLi @ /search.php  payload: ' OR '1'='1

[*] Running XSS scan...
[-] HIGH: Reflected XSS @ /comment.php

[*] Checking security headers...
[!] Missing: Strict-Transport-Security
[!] Missing: Content-Security-Policy

══════════════════════════
  SCAN COMPLETE
  Time: 8.42s | Pages: 12
  CRITICAL : 1
  HIGH     : 4
  MEDIUM   : 3
══════════════════════════
```

---

## ⚠️ Legal & Ethical Notice

> **IMPORTANT:** Only scan systems you own or have **explicit written permission** to test.
> Unauthorised scanning of websites is illegal under the Computer Fraud and Abuse Act (CFAA),
> UK Computer Misuse Act, and equivalent laws worldwide.
>
> This tool is built **solely for academic and educational purposes**.

---

## 📚 References

- OWASP Top 10 – https://owasp.org/Top10/
- CVE Database – https://cve.mitre.org/
- NIST NVD – https://nvd.nist.gov/
- PortSwigger Web Security Academy – https://portswigger.net/web-security
