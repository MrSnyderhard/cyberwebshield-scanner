#!/usr/bin/env python3
"""
=============================================================
  Design and Development of an Automated Web Vulnerability
  Scanner Using Python
  
  Author  : Cybersecurity Research Project
  Version : 1.0.0
  Purpose : Academic / Ethical Security Research Only
=============================================================
"""

import requests
import socket
import ssl
import re
import json
import time
import threading
import urllib.parse
from datetime import datetime
from colorama import Fore, Style, init
from bs4 import BeautifulSoup
import warnings
warnings.filterwarnings("ignore")

init(autoreset=True)

# ─── Colour Helpers ──────────────────────────────────────────
OK   = f"{Fore.GREEN}[+]{Style.RESET_ALL}"
WARN = f"{Fore.YELLOW}[!]{Style.RESET_ALL}"
FAIL = f"{Fore.RED}[-]{Style.RESET_ALL}"
INFO = f"{Fore.CYAN}[*]{Style.RESET_ALL}"


# ═══════════════════════════════════════════════════════════════
#  MODULE 1 – SQL Injection Detection
# ═══════════════════════════════════════════════════════════════
class SQLInjectionScanner:
    """Detects potential SQL Injection vulnerabilities."""

    PAYLOADS = [
        "'", '"', "' OR '1'='1", "' OR 1=1--",
        "' OR 'x'='x", "; DROP TABLE users;--",
        "1' AND 1=1--", "1' AND 1=2--",
        "' UNION SELECT NULL--", "admin'--",
    ]

    DB_ERRORS = [
        "you have an error in your sql syntax",
        "warning: mysql", "unclosed quotation mark",
        "quoted string not properly terminated",
        "microsoft ole db provider for sql server",
        "odbc sql server driver", "sqlite_error",
        "pg::syntaxerror", "ora-00907", "syntax error",
    ]

    def __init__(self, session, base_url):
        self.session   = session
        self.base_url  = base_url
        self.findings  = []

    def scan(self, forms, url):
        print(f"\n{INFO} Running SQL Injection scan on {url}")
        for form in forms:
            for payload in self.PAYLOADS:
                data = {}
                for inp in form.get("inputs", []):
                    data[inp["name"]] = payload
                try:
                    action = form.get("action", url)
                    method = form.get("method", "get").lower()
                    if method == "post":
                        r = self.session.post(action, data=data, timeout=10, verify=False)
                    else:
                        r = self.session.get(action, params=data, timeout=10, verify=False)

                    body = r.text.lower()
                    for err in self.DB_ERRORS:
                        if err in body:
                            finding = {
                                "type"    : "SQL Injection",
                                "severity": "CRITICAL",
                                "url"     : action,
                                "payload" : payload,
                                "detail"  : f"DB error keyword found: '{err}'",
                            }
                            self.findings.append(finding)
                            print(f"{FAIL} SQLi detected at {action} with payload: {payload}")
                            break
                except Exception as e:
                    print(f"{WARN} SQLi scan error: {e}")
        if not self.findings:
            print(f"{OK} No SQL Injection vulnerabilities found.")
        return self.findings


# ═══════════════════════════════════════════════════════════════
#  MODULE 2 – XSS Detection
# ═══════════════════════════════════════════════════════════════
class XSSScanner:
    """Detects reflected Cross-Site Scripting vulnerabilities."""

    PAYLOADS = [
        "<script>alert('XSS')</script>",
        "<img src=x onerror=alert(1)>",
        "'\"><script>alert(1)</script>",
        "<svg onload=alert(1)>",
        "javascript:alert(1)",
        "<body onload=alert('XSS')>",
        "';alert('XSS')//",
        "<iframe src=javascript:alert(1)>",
    ]

    def __init__(self, session, base_url):
        self.session  = session
        self.base_url = base_url
        self.findings = []

    def scan(self, forms, url):
        print(f"\n{INFO} Running XSS scan on {url}")
        for form in forms:
            for payload in self.PAYLOADS:
                data = {}
                for inp in form.get("inputs", []):
                    data[inp["name"]] = payload
                try:
                    action = form.get("action", url)
                    method = form.get("method", "get").lower()
                    if method == "post":
                        r = self.session.post(action, data=data, timeout=10, verify=False)
                    else:
                        r = self.session.get(action, params=data, timeout=10, verify=False)

                    if payload in r.text:
                        finding = {
                            "type"    : "XSS (Reflected)",
                            "severity": "HIGH",
                            "url"     : action,
                            "payload" : payload,
                            "detail"  : "Payload reflected in response body.",
                        }
                        self.findings.append(finding)
                        print(f"{FAIL} XSS reflected at {action}")
                except Exception as e:
                    print(f"{WARN} XSS scan error: {e}")
        if not self.findings:
            print(f"{OK} No reflected XSS vulnerabilities found.")
        return self.findings


# ═══════════════════════════════════════════════════════════════
#  MODULE 3 – Security Headers Check
# ═══════════════════════════════════════════════════════════════
class HeaderScanner:
    """Checks HTTP security headers."""

    REQUIRED = {
        "Strict-Transport-Security" : "Enforces HTTPS connections.",
        "X-Content-Type-Options"    : "Prevents MIME sniffing.",
        "X-Frame-Options"           : "Prevents clickjacking.",
        "Content-Security-Policy"   : "Controls resource loading.",
        "X-XSS-Protection"          : "Enables browser XSS filter.",
        "Referrer-Policy"           : "Controls referrer information.",
        "Permissions-Policy"        : "Controls browser feature access.",
    }

    def __init__(self, session, base_url):
        self.session  = session
        self.base_url = base_url
        self.findings = []

    def scan(self):
        print(f"\n{INFO} Checking security headers for {self.base_url}")
        try:
            r = self.session.get(self.base_url, timeout=10, verify=False)
            for header, desc in self.REQUIRED.items():
                if header not in r.headers:
                    finding = {
                        "type"    : "Missing Security Header",
                        "severity": "MEDIUM",
                        "url"     : self.base_url,
                        "payload" : "N/A",
                        "detail"  : f"Missing: {header} – {desc}",
                    }
                    self.findings.append(finding)
                    print(f"{WARN} Missing header: {header}")
                else:
                    print(f"{OK} Header present: {header}")
        except Exception as e:
            print(f"{WARN} Header scan error: {e}")
        return self.findings


# ═══════════════════════════════════════════════════════════════
#  MODULE 4 – Open Redirect Detection
# ═══════════════════════════════════════════════════════════════
class OpenRedirectScanner:
    """Checks for open redirect vulnerabilities."""

    PAYLOADS = [
        "https://evil.com",
        "//evil.com",
        "https://google.com",
        "/\\evil.com",
    ]
    PARAMS = ["redirect", "url", "next", "return", "to", "goto", "dest", "destination"]

    def __init__(self, session, base_url):
        self.session  = session
        self.base_url = base_url
        self.findings = []

    def scan(self, links):
        print(f"\n{INFO} Running Open Redirect scan")
        tested = set()
        for link in links:
            parsed = urllib.parse.urlparse(link)
            qs     = urllib.parse.parse_qs(parsed.query)
            for param in self.PARAMS:
                if param in qs and link not in tested:
                    tested.add(link)
                    for payload in self.PAYLOADS:
                        new_qs = dict(qs)
                        new_qs[param] = [payload]
                        new_url = parsed._replace(
                            query=urllib.parse.urlencode(new_qs, doseq=True)
                        ).geturl()
                        try:
                            r = self.session.get(new_url, timeout=10,
                                                 allow_redirects=True, verify=False)
                            if "evil.com" in r.url or "google.com" in r.url:
                                finding = {
                                    "type"    : "Open Redirect",
                                    "severity": "MEDIUM",
                                    "url"     : new_url,
                                    "payload" : payload,
                                    "detail"  : f"Redirected to: {r.url}",
                                }
                                self.findings.append(finding)
                                print(f"{FAIL} Open Redirect at {new_url}")
                        except Exception:
                            pass
        if not self.findings:
            print(f"{OK} No open redirects found.")
        return self.findings


# ═══════════════════════════════════════════════════════════════
#  MODULE 5 – SSL/TLS Analysis
# ═══════════════════════════════════════════════════════════════
class SSLScanner:
    """Analyses SSL/TLS configuration."""

    def __init__(self, base_url):
        self.base_url = base_url
        self.findings = []

    def scan(self):
        print(f"\n{INFO} Running SSL/TLS analysis")
        parsed = urllib.parse.urlparse(self.base_url)
        host   = parsed.hostname
        port   = parsed.port or 443

        if parsed.scheme != "https":
            self.findings.append({
                "type"    : "No HTTPS",
                "severity": "HIGH",
                "url"     : self.base_url,
                "payload" : "N/A",
                "detail"  : "Site does not use HTTPS.",
            })
            print(f"{FAIL} Site does not use HTTPS!")
            return self.findings

        try:
            ctx  = ssl.create_default_context()
            conn = ctx.wrap_socket(socket.create_connection((host, port), timeout=10),
                                   server_hostname=host)
            info = conn.getpeercert()
            conn.close()

            # Check expiry
            exp_str = info.get("notAfter", "")
            if exp_str:
                exp_dt = datetime.strptime(exp_str, "%b %d %H:%M:%S %Y %Z")
                days   = (exp_dt - datetime.utcnow()).days
                if days < 30:
                    self.findings.append({
                        "type"    : "SSL Certificate Expiry",
                        "severity": "HIGH",
                        "url"     : self.base_url,
                        "payload" : "N/A",
                        "detail"  : f"Certificate expires in {days} days.",
                    })
                    print(f"{WARN} Certificate expires in {days} days!")
                else:
                    print(f"{OK} Certificate valid for {days} more days.")
        except ssl.SSLCertVerificationError:
            self.findings.append({
                "type"    : "Invalid SSL Certificate",
                "severity": "HIGH",
                "url"     : self.base_url,
                "payload" : "N/A",
                "detail"  : "SSL certificate verification failed.",
            })
            print(f"{FAIL} SSL certificate verification failed!")
        except Exception as e:
            print(f"{WARN} SSL scan error: {e}")
        return self.findings


# ═══════════════════════════════════════════════════════════════
#  MODULE 6 – Sensitive File Exposure
# ═══════════════════════════════════════════════════════════════
class SensitiveFileScanner:
    """Checks for accidentally exposed sensitive files."""

    FILES = [
        ".env", ".git/config", ".htaccess", "robots.txt",
        "web.config", "config.php", "wp-config.php",
        "phpinfo.php", "info.php", "test.php",
        "backup.zip", "database.sql", "db_backup.sql",
        "admin/", "phpmyadmin/", ".DS_Store",
        "sitemap.xml", "crossdomain.xml",
    ]

    def __init__(self, session, base_url):
        self.session  = session
        self.base_url = base_url.rstrip("/")
        self.findings = []

    def scan(self):
        print(f"\n{INFO} Checking for sensitive file exposure")
        for path in self.FILES:
            url = f"{self.base_url}/{path}"
            try:
                r = self.session.get(url, timeout=8, verify=False)
                if r.status_code == 200:
                    self.findings.append({
                        "type"    : "Sensitive File Exposed",
                        "severity": "HIGH",
                        "url"     : url,
                        "payload" : "N/A",
                        "detail"  : f"HTTP 200 returned for {path}",
                    })
                    print(f"{FAIL} Exposed: {url}")
                else:
                    print(f"{OK} Not found (HTTP {r.status_code}): {path}")
            except Exception:
                pass
        return self.findings


# ═══════════════════════════════════════════════════════════════
#  CORE – Web Crawler & Form Extractor
# ═══════════════════════════════════════════════════════════════
class Crawler:
    """Simple single-domain crawler."""

    def __init__(self, session, base_url, max_pages=20):
        self.session   = session
        self.base_url  = base_url
        self.max_pages = max_pages
        self.visited   = set()
        self.forms     = []
        self.links     = []

    def _extract(self, url, html):
        soup = BeautifulSoup(html, "html.parser")

        # Collect links
        for a in soup.find_all("a", href=True):
            href = urllib.parse.urljoin(url, a["href"])
            if self.base_url in href and href not in self.visited:
                self.links.append(href)

        # Collect forms
        for form in soup.find_all("form"):
            action = urllib.parse.urljoin(url, form.get("action", url))
            inputs = []
            for inp in form.find_all(["input", "textarea", "select"]):
                name = inp.get("name")
                if name:
                    inputs.append({"name": name, "type": inp.get("type", "text")})
            self.forms.append({
                "action": action,
                "method": form.get("method", "get"),
                "inputs": inputs,
            })

    def crawl(self):
        queue = [self.base_url]
        print(f"\n{INFO} Crawling {self.base_url} (max {self.max_pages} pages)")
        while queue and len(self.visited) < self.max_pages:
            url = queue.pop(0)
            if url in self.visited:
                continue
            try:
                r = self.session.get(url, timeout=10, verify=False)
                self.visited.add(url)
                print(f"  {INFO} Crawled: {url} [{r.status_code}]")
                self._extract(url, r.text)
                queue.extend([l for l in self.links if l not in self.visited])
            except Exception as e:
                print(f"  {WARN} Crawl error ({url}): {e}")
        print(f"{OK} Crawl complete. Pages: {len(self.visited)}, Forms: {len(self.forms)}")
        return self.forms, list(self.visited), self.links


# ═══════════════════════════════════════════════════════════════
#  REPORT GENERATOR
# ═══════════════════════════════════════════════════════════════
class ReportGenerator:
    """Generates JSON and text reports."""

    SEVERITY_ORDER = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}

    def __init__(self, target, findings, pages_crawled, scan_time):
        self.target        = target
        self.findings      = sorted(findings,
                                    key=lambda x: self.SEVERITY_ORDER.get(x["severity"], 99))
        self.pages_crawled = pages_crawled
        self.scan_time     = scan_time

    def _counts(self):
        c = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0}
        for f in self.findings:
            sev = f.get("severity", "LOW")
            c[sev] = c.get(sev, 0) + 1
        return c

    def save_json(self, path):
        report = {
            "target"        : self.target,
            "scan_date"     : datetime.now().isoformat(),
            "pages_crawled" : self.pages_crawled,
            "scan_time_sec" : round(self.scan_time, 2),
            "total_findings": len(self.findings),
            "severity_counts": self._counts(),
            "findings"      : self.findings,
        }
        with open(path, "w") as f:
            json.dump(report, f, indent=2)
        print(f"\n{OK} JSON report saved → {path}")
        return report

    def save_text(self, path):
        c = self._counts()
        lines = [
            "=" * 65,
            "  AUTOMATED WEB VULNERABILITY SCANNER – SCAN REPORT",
            "=" * 65,
            f"  Target      : {self.target}",
            f"  Scan Date   : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            f"  Pages       : {self.pages_crawled}",
            f"  Scan Time   : {self.scan_time:.2f}s",
            f"  Total Issues: {len(self.findings)}",
            "",
            "  SEVERITY SUMMARY",
            f"  CRITICAL : {c['CRITICAL']}",
            f"  HIGH     : {c['HIGH']}",
            f"  MEDIUM   : {c['MEDIUM']}",
            f"  LOW      : {c['LOW']}",
            "=" * 65,
            "",
            "FINDINGS",
            "-" * 65,
        ]
        for i, f in enumerate(self.findings, 1):
            lines += [
                f"[{i}] {f['type']}",
                f"    Severity : {f['severity']}",
                f"    URL      : {f['url']}",
                f"    Payload  : {f['payload']}",
                f"    Detail   : {f['detail']}",
                "",
            ]
        with open(path, "w") as fh:
            fh.write("\n".join(lines))
        print(f"{OK} Text report saved → {path}")


# ═══════════════════════════════════════════════════════════════
#  MAIN SCANNER ORCHESTRATOR
# ═══════════════════════════════════════════════════════════════
class VulnerabilityScanner:
    """Orchestrates all scanning modules."""

    BANNER = f"""
{Fore.RED}
 ██╗   ██╗██╗   ██╗██╗     ███╗   ██╗███████╗ ██████╗ █████╗ ███╗   ██╗
 ██║   ██║██║   ██║██║     ████╗  ██║██╔════╝██╔════╝██╔══██╗████╗  ██║
 ██║   ██║██║   ██║██║     ██╔██╗ ██║███████╗██║     ███████║██╔██╗ ██║
 ╚██╗ ██╔╝██║   ██║██║     ██║╚██╗██║╚════██║██║     ██╔══██║██║╚██╗██║
  ╚████╔╝ ╚██████╔╝███████╗██║ ╚████║███████║╚██████╗██║  ██║██║ ╚████║
   ╚═══╝   ╚═════╝ ╚══════╝╚═╝  ╚═══╝╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝
{Style.RESET_ALL}
{Fore.CYAN}  Automated Web Vulnerability Scanner | Python | Academic Use Only{Style.RESET_ALL}
"""

    def __init__(self, target, output_dir="reports"):
        import os
        self.target     = target
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": "Mozilla/5.0 (VulnScanner/1.0; Academic Research)"
        })
        self.all_findings = []

    def run(self):
        print(self.BANNER)
        print(f"{INFO} Target: {self.target}")
        print(f"{INFO} Started: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")

        start = time.time()

        # 1. Crawl
        crawler = Crawler(self.session, self.target, max_pages=15)
        forms, pages, links = crawler.crawl()

        # 2. SQL Injection
        sqli = SQLInjectionScanner(self.session, self.target)
        self.all_findings += sqli.scan(forms, self.target)

        # 3. XSS
        xss = XSSScanner(self.session, self.target)
        self.all_findings += xss.scan(forms, self.target)

        # 4. Security Headers
        hdrs = HeaderScanner(self.session, self.target)
        self.all_findings += hdrs.scan()

        # 5. Open Redirect
        ored = OpenRedirectScanner(self.session, self.target)
        self.all_findings += ored.scan(links)

        # 6. SSL/TLS
        ssl_scan = SSLScanner(self.target)
        self.all_findings += ssl_scan.scan()

        # 7. Sensitive Files
        sens = SensitiveFileScanner(self.session, self.target)
        self.all_findings += sens.scan()

        elapsed = time.time() - start

        # Report
        ts  = datetime.now().strftime("%Y%m%d_%H%M%S")
        rpt = ReportGenerator(self.target, self.all_findings, len(pages), elapsed)
        rpt.save_json(f"{self.output_dir}/report_{ts}.json")
        rpt.save_text(f"{self.output_dir}/report_{ts}.txt")

        # Summary
        print(f"\n{'='*60}")
        print(f"{Fore.CYAN}  SCAN COMPLETE{Style.RESET_ALL}")
        print(f"  Time Taken  : {elapsed:.2f}s")
        print(f"  Pages Scanned: {len(pages)}")
        print(f"  Total Issues : {len(self.all_findings)}")
        for sev in ["CRITICAL","HIGH","MEDIUM","LOW"]:
            count = sum(1 for f in self.all_findings if f["severity"] == sev)
            colour = {
                "CRITICAL": Fore.RED, "HIGH": Fore.YELLOW,
                "MEDIUM": Fore.BLUE,  "LOW": Fore.GREEN,
            }[sev]
            print(f"  {colour}{sev:10}{Style.RESET_ALL}: {count}")
        print(f"{'='*60}\n")


# ─── Entry Point ─────────────────────────────────────────────
if __name__ == "__main__":
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else "http://testphp.vulnweb.com"
    scanner = VulnerabilityScanner(target)
    scanner.run()
